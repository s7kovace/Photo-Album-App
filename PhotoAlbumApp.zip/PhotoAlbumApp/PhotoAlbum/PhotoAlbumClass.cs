﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhotoAlbum
{
    class PhotoAlbumClass
    {
        private string formName;
        private string albumPath;
        public List<PhotoClass> photosAndDescriptions = new List<PhotoClass>();


        public PhotoAlbumClass()
        {

        }
        public string FormName
        {
            get { return formName; }

            set { formName = value; }
        }
        public string AlbumPath
        {
            get { return albumPath; }

            set { albumPath = value; }
        }
    }
}
