﻿namespace PhotoAlbum
{
    partial class PhotoAlbumForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picDisplayPictures = new System.Windows.Forms.PictureBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.pnlNavigationPanel = new System.Windows.Forms.Panel();
            this.lblFileCreationTimeAndDate = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnAddPhotos = new System.Windows.Forms.Button();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.btnSaveAlbum = new System.Windows.Forms.Button();
            this.btnOpenAlbum = new System.Windows.Forms.Button();
            this.btnCreateAlbum = new System.Windows.Forms.Button();
            this.grbCanvasColour = new System.Windows.Forms.GroupBox();
            this.rdbGrey = new System.Windows.Forms.RadioButton();
            this.rdbWhite = new System.Windows.Forms.RadioButton();
            this.rdbBlack = new System.Windows.Forms.RadioButton();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.picDisplayPictures)).BeginInit();
            this.pnlNavigationPanel.SuspendLayout();
            this.grbCanvasColour.SuspendLayout();
            this.SuspendLayout();
            // 
            // picDisplayPictures
            // 
            this.picDisplayPictures.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picDisplayPictures.Location = new System.Drawing.Point(12, 25);
            this.picDisplayPictures.Name = "picDisplayPictures";
            this.picDisplayPictures.Size = new System.Drawing.Size(528, 529);
            this.picDisplayPictures.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picDisplayPictures.TabIndex = 0;
            this.picDisplayPictures.TabStop = false;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(3, 10);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(93, 20);
            this.lblDescription.TabIndex = 1;
            this.lblDescription.Text = "Description:";
            // 
            // pnlNavigationPanel
            // 
            this.pnlNavigationPanel.Controls.Add(this.lblFileCreationTimeAndDate);
            this.pnlNavigationPanel.Controls.Add(this.btnNext);
            this.pnlNavigationPanel.Controls.Add(this.btnPrevious);
            this.pnlNavigationPanel.Controls.Add(this.btnAddPhotos);
            this.pnlNavigationPanel.Controls.Add(this.txtDescription);
            this.pnlNavigationPanel.Controls.Add(this.lblDescription);
            this.pnlNavigationPanel.Enabled = false;
            this.pnlNavigationPanel.Location = new System.Drawing.Point(546, 25);
            this.pnlNavigationPanel.Name = "pnlNavigationPanel";
            this.pnlNavigationPanel.Size = new System.Drawing.Size(412, 313);
            this.pnlNavigationPanel.TabIndex = 2;
            // 
            // lblFileCreationTimeAndDate
            // 
            this.lblFileCreationTimeAndDate.AutoSize = true;
            this.lblFileCreationTimeAndDate.Location = new System.Drawing.Point(7, 228);
            this.lblFileCreationTimeAndDate.Name = "lblFileCreationTimeAndDate";
            this.lblFileCreationTimeAndDate.Size = new System.Drawing.Size(13, 20);
            this.lblFileCreationTimeAndDate.TabIndex = 7;
            this.lblFileCreationTimeAndDate.Text = " ";
            this.lblFileCreationTimeAndDate.Visible = false;
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(275, 267);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(128, 32);
            this.btnNext.TabIndex = 6;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(141, 267);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(128, 32);
            this.btnPrevious.TabIndex = 5;
            this.btnPrevious.Text = "Previous";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnAddPhotos
            // 
            this.btnAddPhotos.Location = new System.Drawing.Point(7, 267);
            this.btnAddPhotos.Name = "btnAddPhotos";
            this.btnAddPhotos.Size = new System.Drawing.Size(128, 32);
            this.btnAddPhotos.TabIndex = 4;
            this.btnAddPhotos.Text = "Add Photos";
            this.btnAddPhotos.UseVisualStyleBackColor = true;
            this.btnAddPhotos.Click += new System.EventHandler(this.btnAddPhotos_Click);
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(7, 33);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(396, 178);
            this.txtDescription.TabIndex = 3;
            this.txtDescription.TextChanged += new System.EventHandler(this.txtDescription_TextChanged);
            // 
            // btnSaveAlbum
            // 
            this.btnSaveAlbum.Enabled = false;
            this.btnSaveAlbum.Location = new System.Drawing.Point(821, 522);
            this.btnSaveAlbum.Name = "btnSaveAlbum";
            this.btnSaveAlbum.Size = new System.Drawing.Size(128, 32);
            this.btnSaveAlbum.TabIndex = 9;
            this.btnSaveAlbum.Text = "Save Album";
            this.btnSaveAlbum.UseVisualStyleBackColor = true;
            this.btnSaveAlbum.Click += new System.EventHandler(this.btnSaveAlbum_Click);
            // 
            // btnOpenAlbum
            // 
            this.btnOpenAlbum.Location = new System.Drawing.Point(687, 522);
            this.btnOpenAlbum.Name = "btnOpenAlbum";
            this.btnOpenAlbum.Size = new System.Drawing.Size(128, 32);
            this.btnOpenAlbum.TabIndex = 8;
            this.btnOpenAlbum.Text = "Open Album";
            this.btnOpenAlbum.UseVisualStyleBackColor = true;
            this.btnOpenAlbum.Click += new System.EventHandler(this.btnOpenAlbum_Click);
            // 
            // btnCreateAlbum
            // 
            this.btnCreateAlbum.Location = new System.Drawing.Point(553, 522);
            this.btnCreateAlbum.Name = "btnCreateAlbum";
            this.btnCreateAlbum.Size = new System.Drawing.Size(128, 32);
            this.btnCreateAlbum.TabIndex = 7;
            this.btnCreateAlbum.Text = "Create Album";
            this.btnCreateAlbum.UseVisualStyleBackColor = true;
            this.btnCreateAlbum.Click += new System.EventHandler(this.btnCreateAlbum_Click);
            // 
            // grbCanvasColour
            // 
            this.grbCanvasColour.Controls.Add(this.rdbGrey);
            this.grbCanvasColour.Controls.Add(this.rdbWhite);
            this.grbCanvasColour.Controls.Add(this.rdbBlack);
            this.grbCanvasColour.Location = new System.Drawing.Point(546, 344);
            this.grbCanvasColour.Name = "grbCanvasColour";
            this.grbCanvasColour.Size = new System.Drawing.Size(412, 158);
            this.grbCanvasColour.TabIndex = 10;
            this.grbCanvasColour.TabStop = false;
            this.grbCanvasColour.Text = "Canvas Colour";
            // 
            // rdbGrey
            // 
            this.rdbGrey.AutoSize = true;
            this.rdbGrey.Location = new System.Drawing.Point(321, 74);
            this.rdbGrey.Name = "rdbGrey";
            this.rdbGrey.Size = new System.Drawing.Size(68, 24);
            this.rdbGrey.TabIndex = 2;
            this.rdbGrey.TabStop = true;
            this.rdbGrey.Text = "Grey";
            this.rdbGrey.UseVisualStyleBackColor = true;
            this.rdbGrey.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // rdbWhite
            // 
            this.rdbWhite.AutoSize = true;
            this.rdbWhite.Location = new System.Drawing.Point(171, 74);
            this.rdbWhite.Name = "rdbWhite";
            this.rdbWhite.Size = new System.Drawing.Size(75, 24);
            this.rdbWhite.TabIndex = 1;
            this.rdbWhite.TabStop = true;
            this.rdbWhite.Text = "White";
            this.rdbWhite.UseVisualStyleBackColor = true;
            this.rdbWhite.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // rdbBlack
            // 
            this.rdbBlack.AutoSize = true;
            this.rdbBlack.Location = new System.Drawing.Point(23, 74);
            this.rdbBlack.Name = "rdbBlack";
            this.rdbBlack.Size = new System.Drawing.Size(73, 24);
            this.rdbBlack.TabIndex = 0;
            this.rdbBlack.TabStop = true;
            this.rdbBlack.Text = "Black";
            this.rdbBlack.UseVisualStyleBackColor = true;
            this.rdbBlack.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            this.openFileDialog.Multiselect = true;
            // 
            // PhotoAlbumForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 575);
            this.Controls.Add(this.grbCanvasColour);
            this.Controls.Add(this.btnSaveAlbum);
            this.Controls.Add(this.btnOpenAlbum);
            this.Controls.Add(this.btnCreateAlbum);
            this.Controls.Add(this.pnlNavigationPanel);
            this.Controls.Add(this.picDisplayPictures);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "PhotoAlbumForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Photo Album";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PhotoAlbumForm_FormClosing);
            this.Load += new System.EventHandler(this.PhotoAlbumForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picDisplayPictures)).EndInit();
            this.pnlNavigationPanel.ResumeLayout(false);
            this.pnlNavigationPanel.PerformLayout();
            this.grbCanvasColour.ResumeLayout(false);
            this.grbCanvasColour.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picDisplayPictures;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Panel pnlNavigationPanel;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnAddPhotos;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Button btnSaveAlbum;
        private System.Windows.Forms.Button btnOpenAlbum;
        private System.Windows.Forms.Button btnCreateAlbum;
        private System.Windows.Forms.GroupBox grbCanvasColour;
        private System.Windows.Forms.RadioButton rdbGrey;
        private System.Windows.Forms.RadioButton rdbWhite;
        private System.Windows.Forms.RadioButton rdbBlack;
        private System.Windows.Forms.Label lblFileCreationTimeAndDate;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
    }
}

