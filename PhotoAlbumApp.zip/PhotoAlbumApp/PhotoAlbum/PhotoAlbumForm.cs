﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhotoAlbum
{
    public partial class PhotoAlbumForm : Form
    {
        PhotoClass activePhoto;
        PhotoAlbumClass activeAlbum;
        int index = 0;
        string albumName;

        public PhotoAlbumForm()
        {
            InitializeComponent();

        }

        private void PhotoAlbumForm_Load(object sender, EventArgs e)
        {
            rdbBlack.Checked = true;
        }

        private void RadioButtons_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbBlack.Checked == true)
            {
                picDisplayPictures.BackColor = Color.Black;
            }
            else if (rdbWhite.Checked == true)
            {
                picDisplayPictures.BackColor = Color.White;
            }
            else if (rdbGrey.Checked == true)
            {
                picDisplayPictures.BackColor = Color.Gray;
            }

        }

        private void btnCreateAlbum_Click(object sender, EventArgs e)
        {
            AlbumCreationForm secondayForm = new AlbumCreationForm();

            if (activeAlbum == null)
            {
                if (secondayForm.ShowDialog(this) == DialogResult.OK)
                {

                    this.Text = $"Photo Album - {secondayForm.GetTextFromBox()}";
                    btnSaveAlbum.Enabled = true;
                    pnlNavigationPanel.Enabled = true;
                    btnPrevious.Enabled = false;
                    btnNext.Enabled = false;
                    btnAddPhotos.Enabled = true;
                    PhotoAlbumClass photoAlbumClass = new PhotoAlbumClass();
                    photoAlbumClass.FormName = secondayForm.GetTextFromBox();
                    albumName = secondayForm.GetTextFromBox();
                    activeAlbum = photoAlbumClass;
                    

                }

            }
            else if (activeAlbum != null)
            {

                DialogResult result = MessageBox.Show("Would you like to save your current photo Album?", "Save Album", MessageBoxButtons.YesNoCancel);
                if (result == DialogResult.Yes)
                {
                    SaveFileDialog saveFileDialog = new SaveFileDialog();
                    saveFileDialog.Filter = "Album(*.alb)|*.alb";
                    saveFileDialog.FileName = albumName;
                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string filePath = saveFileDialog.FileName;
                        activeAlbum.AlbumPath = filePath;
                        using (StreamWriter sw = new StreamWriter(filePath))
                        {
                            sw.WriteLine(albumName);
                            foreach (PhotoClass photo in activeAlbum.photosAndDescriptions)
                            {
                                sw.WriteLine($"{photo.FilePath}|{photo.Description}|{photo.CreationTimeAndDate}");

                            }

                        }

                    }
                }
                else if (result == DialogResult.No)
                {
                    activeAlbum = null;
                    activePhoto = null;
                    albumName = null;
                    pnlNavigationPanel.Enabled = false;
                    btnSaveAlbum.Enabled = false;
                    this.Text = "Photo Album";
                    picDisplayPictures.ImageLocation = null;
                    txtDescription.TextChanged -= new EventHandler(txtDescription_TextChanged);
                    txtDescription.Clear();
                    lblFileCreationTimeAndDate.Text = null;
                }
            }

        }




        private void btnAddPhotos_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Images Files(*.jpeg;*.jpg)|*.jpeg;*.jpg";
            openFileDialog.Multiselect = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string[] filePaths = openFileDialog.FileNames;

                for (int i = 0; i < filePaths.Length; i++)
                {

                    DateTime fileCreatedDate = DateTime.Now;
                    PhotoClass photoClass = new PhotoClass();
                    activeAlbum.photosAndDescriptions.Add(photoClass);
                    photoClass.FilePath = filePaths[i];
                    photoClass.CreationTimeAndDate = fileCreatedDate.ToString();

                }

                activePhoto = activeAlbum.photosAndDescriptions[index];
                UpdateForm();
                txtDescription.TextChanged += new EventHandler(txtDescription_TextChanged);
                if (activeAlbum.photosAndDescriptions.Count > 1)
                {
                    btnNext.Enabled = true;
                    btnPrevious.Enabled = true;
                }

            }
        }


        private void btnNext_Click(object sender, EventArgs e)
        {
            if (index < activeAlbum.photosAndDescriptions.Count - 1)
            {
                index++;
                activePhoto = activeAlbum.photosAndDescriptions[index];
                UpdateForm();

            }
            else
            {
                index = 0;
                activePhoto = activeAlbum.photosAndDescriptions[index];
                UpdateForm();

            }

        }


        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (index > 0)
            {
                index--;
                activePhoto = activeAlbum.photosAndDescriptions[index];
                UpdateForm();

            }
            else
                index = activeAlbum.photosAndDescriptions.Count - 1;
            activePhoto = activeAlbum.photosAndDescriptions[index];
            UpdateForm();

        }

        private void btnSaveAlbum_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Album(*.alb)|*.alb";
            saveFileDialog.FileName = activeAlbum.FormName;
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = saveFileDialog.FileName;
                activeAlbum.AlbumPath = filePath;
                using (StreamWriter sw = new StreamWriter(filePath))
                {
                    sw.WriteLine(activeAlbum.FormName);
                    foreach (PhotoClass photo in activeAlbum.photosAndDescriptions)
                    {
                        sw.WriteLine($"{photo.FilePath}|{photo.Description}|{photo.CreationTimeAndDate}");
                        
                    }

                    DialogResult result = MessageBox.Show($"Album {activeAlbum.FormName} saved!", "Saved", MessageBoxButtons.OK);

                }

            }
        }

        private void btnOpenAlbum_Click(object sender, EventArgs e)
        {
            char delimiter = '|';
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Album File(*.alb)|*.alb";
            openFileDialog.Multiselect = false;
            List<string> photoPaths = new List<string>();
            List<string> descriptions = new List<string>();
            List<string> creationDateandTimes = new List<string>();

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;

                if (filePath != null)
                {
                    using (StreamReader sr = new StreamReader(filePath))
                    {
                        string[] readFile = File.ReadAllLines(filePath);
                        this.Text = $"Photo Album - {readFile[0]} {filePath}";

                        for (int i = 1; i < readFile.Length; i++)
                        {

                            string[] splitPhotosAndDescriptions = new string[3];
                            splitPhotosAndDescriptions = readFile[i].Split(delimiter);
                            photoPaths.Add(splitPhotosAndDescriptions[0]);
                            descriptions.Add(splitPhotosAndDescriptions[1]);
                            creationDateandTimes.Add(splitPhotosAndDescriptions[2]);


                        }

                        PhotoAlbumClass photoAlbumClass = new PhotoAlbumClass();

                        for (int i = 0; i < photoPaths.Count; i++)
                        {
                            PhotoClass photoClass = new PhotoClass();
                            photoClass.FilePath = photoPaths[i];
                            photoClass.Description = descriptions[i];
                            photoClass.CreationTimeAndDate = creationDateandTimes[i];
                            photoAlbumClass.photosAndDescriptions.Add(photoClass);

                            
                        }

                        activeAlbum = photoAlbumClass;
                        activeAlbum.FormName = readFile[0];
                        activeAlbum.AlbumPath = filePath;

                        activePhoto = activeAlbum.photosAndDescriptions[0];
                        UpdateForm();
                        btnSaveAlbum.Enabled = true;
                        pnlNavigationPanel.Enabled = true;
                        btnPrevious.Enabled = true;
                        btnNext.Enabled = true;
                        btnAddPhotos.Enabled = true;

                    }

                }
            }


        }
        private void UpdateForm()
        {
            picDisplayPictures.ImageLocation = activePhoto.FilePath;
            txtDescription.Text = activePhoto.Description;
            lblFileCreationTimeAndDate.Visible = true;
            lblFileCreationTimeAndDate.Text = $"File Created: {activePhoto.CreationTimeAndDate}";

        }
        private void txtDescription_TextChanged(object sender, EventArgs e)
        {
            activePhoto.Description = txtDescription.Text;
        }

        private void PhotoAlbumForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (activeAlbum != null) { 
            DialogResult result = MessageBox.Show($"Do you want to save the Album before closing?", "Closing", MessageBoxButtons.YesNoCancel);

                if (result == DialogResult.Yes)
                {
                    SaveFileDialog saveFileDialog = new SaveFileDialog();
                    saveFileDialog.Filter = "Album(*.alb)|*.alb";
                    saveFileDialog.FileName = activeAlbum.FormName;
                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string filePath = saveFileDialog.FileName;
                        activeAlbum.AlbumPath = filePath;
                        using (StreamWriter sw = new StreamWriter(filePath))
                        {
                            sw.WriteLine(activeAlbum.FormName);
                            foreach (PhotoClass photo in activeAlbum.photosAndDescriptions)
                            {
                                sw.WriteLine($"{photo.FilePath}|{photo.Description}|{photo.CreationTimeAndDate}");

                            }


                        }

                    }
                }
                else if (result == DialogResult.No)
                {
                    return;
                }

                else
                    e.Cancel = true;
            }
        }
    }
}
