﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoAlbum
{
    class PhotoClass
    {
        private string filePath;
        private string creationTimeAndDate;
        private string description;

        public PhotoClass()
        {

        }
        public string FilePath
        {
            get { return filePath; }

            set { filePath = value; }
        }
        public string CreationTimeAndDate
        {
            get { return creationTimeAndDate; }

            set { creationTimeAndDate = value; }
        }
        public string Description
        {
            get { return description; }

            set { description = value; }
        }

    }
}
